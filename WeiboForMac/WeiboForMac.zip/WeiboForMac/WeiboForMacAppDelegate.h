//
//  WeiboForMacAppDelegate.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-7-31.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TUIKit.h"
#import "WTPullDownView.h"
#import "WTLoginWindow.h"
#import "WTMainWindow.h"

@interface WeiboForMacAppDelegate : NSObject {
    WTLoginWindow * loginWindowController;
}

- (IBAction) showPreferenceWindow:(id) sender;
-(void) setShouldLogin;

@end
