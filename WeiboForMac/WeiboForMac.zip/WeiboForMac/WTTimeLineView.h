//
//  WTTimeLineView.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"
#import "WTPullDownView.h"
#import "WTTimelineTable.h"

@interface WTTimeLineView : TUIView 
<TUITableViewDelegate , TUITableViewDataSource , WTPullDownViewDelegate , TUITextRendererDelegate , TUIScrollViewDelegate, TUIViewDelegate>
{
    WTTimelineTable * friendTimeline;
    
    NSArray * array;
    
    BOOL shouldUpdate;
    
    TUITextRenderer * heightCalculator;
}

@property (assign) WTTimelineTable * friendTimeline;

@end
