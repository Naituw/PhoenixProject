//
//  WTTimeLineView.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTTimeLineView.h"
#import "WTStatusCell.h"
#import "WTStatus.h"
#import "WTRefreshingCell.h"
#import "WTInformation.h"
#import "TUIImageView+WebCache.h"
#import "WTThumbPicView+webImage.h"
#import "WTPopoverViewController.h"
#import "TUITableView+WTAddition.h"
#import "NSAttributedString+WTAddition.h"
#import "WTDateFormatter.h"
#import "Weibo.h"

@implementation WTTimeLineView
@synthesize friendTimeline;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame{
    if ((self = [super initWithFrame:frame])) {
        shouldUpdate = NO;
        friendTimeline = [[WTTimelineTable alloc] initWithFrame:[self bounds] style:TUITableViewStylePlain];
        [friendTimeline setDelegate:self];
        [friendTimeline setDataSource:self];
        friendTimeline.pullView.delegate = self;
        [self addSubview:friendTimeline];
        
        [friendTimeline reloadData];
        dispatch_queue_t concurrentQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_queue_t mainQueue = dispatch_get_main_queue();
        dispatch_async(concurrentQueue, ^{
            [WTInformation center].array = [[Weibo engine] getFriendsTimeline:0 maxId:0 count:20 page:2];
            dispatch_sync(mainQueue, ^{
                TUIFastIndexPath * index = [TUIFastIndexPath indexPathForRow:0 inSection:0];
                [friendTimeline reloadDataMaintainingVisibleIndexPath:index relativeOffset:0.0];
                shouldUpdate = YES;
            });
        });
    }
    return self;
}

- (void)dealloc{
    [friendTimeline release];
    [super dealloc];
}

- (NSInteger)numberOfSectionsInTableView:(TUITableView *)tableView
{
	return 2;
}

- (NSInteger)tableView:(TUITableView *)table numberOfRowsInSection:(NSInteger)section
{
    if (section == 1) {
        return 1;
    }
	return [[[WTInformation center] array] count];
}

- (CGFloat)tableView:(TUITableView *)tableView heightForRowAtIndexPath:(TUIFastIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        return 40;
    }
    WTStatus * status = [[[WTInformation center] array] objectAtIndex:indexPath.row];
    
    CGFloat fontsize = [[[NSUserDefaults standardUserDefaults] objectForKey:@"fontsize"] floatValue];
    NSFont * font = [NSFont fontWithName:@"HelveticaNeue" size:fontsize];
    [status.content addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, [status.content length])];
    
    // get height of text
    CGFloat height = [status textHeightByWidth:tableView.bounds.size.width-80] + 40;
    
    // if has thumbpic, increase height.
    BOOL showThumbImage = [[[NSUserDefaults standardUserDefaults] objectForKey:@"showThumbImage"] boolValue];
    if (status.thumbPicUrl && showThumbImage) {
        height += 100;
    }
    
    // if final height smaller than 70, than set it to 70.
    if (height < 70) {
        height = 70;
    }
	return height;
}

- (TUIView *)tableView:(TUITableView *)tableView headerViewForSection:(NSInteger)section
{
    return nil;
}


- (TUITableViewCell *)tableView:(TUITableView *)tableView cellForRowAtIndexPath:(TUIFastIndexPath *)indexPath{
    //if is refreshing cell , return a WTRefreshCell
    if (indexPath.section == 1) {
        WTRefreshingCell *cell = reusableTableCellOfClass(tableView, WTRefreshingCell);
        return cell;
    }
    
    WTStatusCell * cell = reusableTableCellOfClass(tableView, WTStatusCell);
    WTStatus * status = [[[WTInformation center] array] objectAtIndex:indexPath.row];
    
    // setup user profile image (Head pic)
    [cell.avatar setImageWithURL:[NSURL URLWithString:status.profileImg]];
    
    cell.thumb.frame = CGRectZero;
    BOOL showThumbImage = [[[NSUserDefaults standardUserDefaults] objectForKey:@"showThumbImage"] boolValue];
    if (status.thumbPicUrl && showThumbImage) {
        [cell.thumb setImageWithURL:[NSURL URLWithString:status.thumbPicUrl]];
        cell.thumb.midPicUrl = status.midPicUrl;
    }
    
    // setup user screen name
    TUIAttributedString *s = [TUIAttributedString stringWithString:status.userName];
	s.color = [TUIColor blackColor];
	s.font = [TUIFont fontWithName:@"HelveticaNeue-Bold" size:13];
    [s setAlignment:TUITextAlignmentLeft lineBreakMode:TUILineBreakModeTailTruncation];
	cell.name.attributedString = s;
    
    NSString * timeString = [[WTDateFormatter shared] stringForTime:status.time];
    TUIAttributedString *time = [TUIAttributedString stringWithString:timeString];
    time.color = [TUIColor colorWithWhite:0.6 alpha:1.0];
    time.font = [TUIFont fontWithName:@"HelveticaNeue" size:11];
    cell.time.attributedString = time;
    
    // setup weibo content
    cell.content.delegate = self;
    cell.content.attributedString = [status content];
    
    cell.viewDelegate = self;
    
    return cell;
}

- (void)tableView:(TUITableView *)tableView willDisplayCell:(TUITableViewCell *)cell forRowAtIndexPath:(TUIFastIndexPath *)indexPath{
    if (indexPath.section == 1 && shouldUpdate) {
        shouldUpdate = NO;
        dispatch_queue_t concurrentQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_queue_t mainQueue = dispatch_get_main_queue();
        dispatch_async(concurrentQueue, ^{
            [[WTInformation center].array addObjectsFromArray:[[Weibo engine] getFriendsTimeline:0 maxId:0 count:200 page:1]];
            [[WTInformation center].array addObjectsFromArray:[[Weibo engine] getFriendsTimeline:0 maxId:0 count:200 page:2]];
            [[WTInformation center].array addObjectsFromArray:[[Weibo engine] getFriendsTimeline:0 maxId:0 count:200 page:3]];
            dispatch_sync(mainQueue, ^{
                [tableView appendNewRows];
                shouldUpdate = YES;
            });
        });
    }
}

- (void)tableViewDidReloadData:(TUITableView *)tableView{
    NSLog(@"reload");
    [tableView setNeedsLayout];
}

- (NSArray *)activeRangesForTextRenderer:(TUITextRenderer *)t{
    NSArray * rangeArray = [t.attributedString activeRanges];
    return rangeArray;
}

- (void)scrollViewDidScroll:(TUIScrollView *)scrollView{
    [[WTPopoverViewController shared] closePopover:self animated:YES];
}

- (void)pullToRefreshViewShouldRefresh:(WTPullDownView *)view{
    dispatch_queue_t concurrentQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    dispatch_async(concurrentQueue, ^{
        [WTInformation center].array = [[Weibo engine] getFriendsTimeline:0 maxId:0 count:40 page:1];
        dispatch_sync(mainQueue, ^{
            [friendTimeline pushNewRowsWithCount:20];
            [view finishedLoading];
            shouldUpdate = YES;
        });
    });
}

@end
