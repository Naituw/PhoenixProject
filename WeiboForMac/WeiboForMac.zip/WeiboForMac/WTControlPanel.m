//
//  WTControlPanel.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-8.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTControlPanel.h"

@implementation WTControlPanel

- (id)init
{
    self = [super init];
    if (self) {
        
        
        replyButton = [[TUIImageView alloc] init];
        retweetButton = [[TUIImageView alloc] init];
        
        replyButton.backgroundColor = [TUIColor clearColor];
        retweetButton.backgroundColor = [TUIColor clearColor];
        
        replyButton.image = [TUIImage imageNamed:@"reply.png"];
        retweetButton.image = [TUIImage imageNamed:@"retweet.png"];
        
        replyButton.frame = CGRectMake(0, 0, 22, 14);
        retweetButton.frame = CGRectMake(28, 2, 20, 11);
        
        replyButton.alpha = 0.3;
        retweetButton.alpha = 0.3;
        
        
        [self addSubview:replyButton];
        [self addSubview:retweetButton];
        //self.viewDelegate = self;
        //replyButton.viewDelegate = self;
        //retweetButton.viewDelegate = self;
    }
    
    return self;
}

- (void)mouseEntered:(NSEvent *)event onSubview:(TUIView *)subview{
    [TUIView animateWithDuration:0.2 animations:^{
        self.alpha = 0.5;
        subview.alpha = 0.8;
    }];
}

- (void)mouseExited:(NSEvent *)event fromSubview:(TUIView *)subview{
    [TUIView animateWithDuration:0.2 animations:^{
        subview.alpha = 0.3;
    }];
}

- (void)mouseExited:(NSEvent *)theEvent{
    if (![self eventInside:theEvent]) {
        [TUIView animateWithDuration:0.2 animations:^{
            self.alpha = 1.0;
        }];
    }
}

- (void)mouseDown:(NSEvent *)event onSubview:(TUIView *)subview{
    subview.alpha = 0.6;
}

- (void)mouseUp:(NSEvent *)event fromSubview:(TUIView *)subview{
    subview.alpha = 0.8;
}

@end
