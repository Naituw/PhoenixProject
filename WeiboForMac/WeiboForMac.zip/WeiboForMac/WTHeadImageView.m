//
//  WTHeadImageView.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTHeadImageView.h"

@implementation WTHeadImageView

- (id)init
{
    self = [super init];
    if (self) {
    }
    
    return self;
}

- (void)prepare{
    //if(_image)[_image release];
    [self setImage:nil];
}

@end
