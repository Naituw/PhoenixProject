//
//  TUIButton+Accessibility.h
//  TwUI
//
//  Created by Josh Abernathy on 7/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TUIButton.h"


@interface TUIButton (Accessibility)

@end
