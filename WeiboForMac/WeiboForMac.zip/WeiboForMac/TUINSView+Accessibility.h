//
//  TUINSView+Accessibility.h
//  TwUI
//
//  Created by Josh Abernathy on 7/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TUINSView.h"


@interface TUINSView (Accessibility)

@end
