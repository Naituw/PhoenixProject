//
//  WTRefreshingCell.m
//  Example
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTRefreshingCell.h"

@implementation WTRefreshingCell

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)dealloc
{
    [activityView release];
    [super dealloc];
}

- (id)initWithStyle:(TUITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
	if((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
		activityView = [[TUIActivityIndicatorView alloc] 
                        initWithActivityIndicatorStyle:TUIActivityIndicatorViewStyleGray];
        activityView.autoresizingMask = TUIViewAutoresizingFlexibleWidth;
		[self addSubview:activityView];
        [activityView startAnimating];
        activityView.alpha = 1.0;
	}
	return self;
}


- (void)drawRect:(CGRect)rect
{
	CGRect b = self.bounds;
	CGContextRef ctx = TUIGraphicsGetCurrentContext();
	
    CGContextSetRGBFillColor(ctx, 245.0/255.0, 245.0/255.0, 245.0/255.0, 1.0); // dark at the bottom
    CGContextFillRect(ctx, CGRectMake(0, 0, b.size.width, b.size.height));
    
    activityView.frame = CGRectMake(b.size.width/2 - 10, b.size.height - 30, 20.0f, 20.0f);
}


@end
