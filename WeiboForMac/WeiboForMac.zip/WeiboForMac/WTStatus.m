//
//  WTStatus.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-5.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTStatus.h"
#import "NSMutableAttributedString+ORSCanaryAdditions.h"
#import "TUIStringDrawing.h"

@interface WTStatus (Private)

- (NSString *) generateStatusStringWithStatus:(Status *)status;
- (NSString *) generateCommentStringWithComment:(WComment *)comment;

@end

@implementation WTStatus

@synthesize type, userName, content, profileImg , thumbPicUrl , midPicUrl , time;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (id)initWithStatus:(Status *)status{
    if ((self = [super init])) {
        type = WTStatusTypeStatus;
        
        NSString * statusString = [self generateStatusStringWithStatus:status];
        content = [[NSMutableAttributedString alloc] 
                   initWithString:statusString];
        NSColor * color = [NSColor colorWithDeviceRed:0.25 
                                                green:0.25
                                                 blue:0.25 
                                                alpha:1.0];
        
        [content addAttribute:NSForegroundColorAttributeName 
                        value:color 
                        range:NSMakeRange(0, [content length])];
        [content highlightElements];
        
        self.userName = status.user.name;
        self.profileImg = status.user.profile_image_url;
        self.thumbPicUrl = status.thumbnail_pic;
        self.midPicUrl = status.bmiddle_pic;
        if (status.retweeted_status.thumbnail_pic) {
            self.thumbPicUrl = status.retweeted_status.thumbnail_pic;
            self.midPicUrl = status.retweeted_status.bmiddle_pic;
        }
        
        self.time = status.created_at;
    }
    return self;
}

- (id)initWithComment:(WComment *)comment{
    if ((self = [super init])) {
        type = WTStatusTypeComment;
        NSString * commentString = [self generateCommentStringWithComment:comment];
        content = [[NSMutableAttributedString alloc]
                   initWithString:commentString];
        [content highlightElements];
        
        userName = comment.user.name;
        profileImg = comment.user.profile_image_url;
        thumbPicUrl = nil;
        if (!comment.reply_comment) {
            thumbPicUrl = comment.status.thumbnail_pic;
        }
    
    }
    return self;
}

- (void)dealloc{
    //[originObject release];
    [content release];
    [userName release];
    [profileImg release];
    [thumbPicUrl release];
    [midPicUrl release];
    [super dealloc];
}

- (NSString *) generateStatusStringWithStatus:(Status *)status{
    NSMutableString * string = [NSMutableString stringWithString:status.text];
    if (status.retweeted_status) {
        [string appendFormat:@"\n\n// @%@:",status.retweeted_status.user.name];
        [string appendString:status.retweeted_status.text];
    }
    return string;
}

- (NSString *) generateCommentStringWithComment:(WComment *)comment{
    NSMutableString * string = [NSMutableString stringWithString:comment.text];
    if (comment.reply_comment){
        [string appendFormat:@"\n\n@%@:",comment.reply_comment.user.name];
        [string appendString:comment.reply_comment.text];
    }
    else{
        [string appendFormat:@"\n\n@%@:",comment.status.user.name];
        [string appendString:comment.status.text];
    }
    return string;
}

- (CGFloat) textHeightByWidth:(CGFloat)width{
    return [content ab_sizeConstrainedToWidth:width].height;
}

@end
