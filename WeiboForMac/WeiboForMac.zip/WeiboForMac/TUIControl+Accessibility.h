//
//  TUIControl+Accessibility.h
//  TwUI
//
//  Created by Josh Abernathy on 7/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TUIControl.h"


@interface TUIControl (Accessibility)

@end
