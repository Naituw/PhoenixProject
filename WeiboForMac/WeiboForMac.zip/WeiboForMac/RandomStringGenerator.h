//
//  RandomStringGenerator.h
//  weibo4objc
//
//  Created by fanng yuan on 3/14/11.
//  Copyright 2011 fanngyuan@sina. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RandomStringGenerator : NSObject {

}

-(NSString *) genRandStringLength: (int) len ;

@end
