//
//  WTTimelineTable.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-28.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"
#import "WTPullDownView.h"

@interface WTTimelineTable : TUITableView {
    WTPullDownView * pullView;
}

@property (assign) WTPullDownView * pullView;

@end
