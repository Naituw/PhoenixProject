//
//  WTControlPanel.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-8.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"

@interface WTControlPanel : TUIView{
    TUITextRenderer * name;
    TUITextRenderer * text;
    
    TUIImageView * replyButton;
    TUIImageView * retweetButton;
}

@end
