//
//  WTStatus.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-5.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Status.h"
#import "WComment.h"

typedef enum {
	WTStatusTypeStatus,
    WTStatusTypeComment
} WTStatusType;

@interface WTStatus : NSObject {
    WTStatusType type;
    NSString * userName;
    NSMutableAttributedString * content;
    
    NSString * profileImg;
    NSString * thumbPicUrl;
    NSString * midPicUrl;
    int time;
}

@property (nonatomic , assign) WTStatusType type;
@property (nonatomic , assign) NSString * userName;
@property (nonatomic , retain) NSMutableAttributedString * content;
@property (nonatomic , retain) NSString * profileImg;
@property (nonatomic , retain) NSString * thumbPicUrl;
@property (nonatomic , retain) NSString * midPicUrl;
@property (nonatomic , assign) int time;

- (id)initWithStatus:(Status *)status;
- (id)initWithComment:(WComment *)comment;

- (CGFloat) textHeightByWidth:(CGFloat)width;
@end
