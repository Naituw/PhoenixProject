//
//  TUITableView+Reload.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-5.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUITableView+WTAddition.h"

@implementation TUITableView (WTAddition)

- (CGPoint) contentOffSet{
    return self.contentOffset;
}

- (TUIFastIndexPath *)indexPathForFirstVisibleRow 
{
	TUIFastIndexPath *firstIndexPath = nil;
	for(TUIFastIndexPath *indexPath in _visibleItems) {
		if(firstIndexPath == nil || [indexPath compare:firstIndexPath] == NSOrderedAscending) {
			firstIndexPath = indexPath;
		}
	}
	return firstIndexPath;
}

- (void) pushNewRowsWithCount:(NSUInteger) count{
    
    TUIFastIndexPath * index = [self indexPathForFirstVisibleRow];
    TUIFastIndexPath * selected = nil;
    if (_selectedIndexPath) {
        selected = [TUIFastIndexPath indexPathForRow:_selectedIndexPath.row+count inSection:0];
    }
    CGRect rect = [self rectForRowAtIndexPath:index];
    
    // calculate relative offset
    CGFloat offset = rect.size.height + (self.contentOffset.y - self.bounds.size.height + rect.origin.y);
    // keep the top row position.
    if (index.row == 0 && index.section == 1) {
        // if first load , keep in top.
        index = [TUIFastIndexPath indexPathForRow:0 inSection:0];
    }
    else{
        index = [TUIFastIndexPath indexPathForRow:index.row+count inSection:index.section];
    }
    // Set content inset to zero , otherwise may occure inset calculate problem after reload.
    [self setContentInset:TUIEdgeInsetsZero];
    [self reloadDataMaintainingVisibleIndexPath:index relativeOffset:-offset];
    // if there are selected row before, reselect it.
    if (selected) {
        [self selectRowAtIndexPath:selected animated:NO scrollPosition:TUITableViewScrollPositionNone];
    }
}

- (void) appendNewRows{
    TUIFastIndexPath * index = [self indexPathForFirstVisibleRow];
    CGRect rect = [self rectForRowAtIndexPath:index];
    CGFloat offset = rect.size.height + (self.contentOffset.y - self.bounds.size.height + rect.origin.y);
    // keep the top row position.
    [self reloadDataMaintainingVisibleIndexPath:index relativeOffset:-offset];
}

@end
