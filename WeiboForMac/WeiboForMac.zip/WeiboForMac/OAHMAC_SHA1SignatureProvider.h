//
//  OAHMAC_SHA1SignatureProvider.h
//  weibo4objc
//
//  Created by fanng yuan on 3/11/11.
//  Copyright 2011 fanngyuan@sina. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OASignatureProviding.h"


@interface OAHMAC_SHA1SignatureProvider : NSObject <OASignatureProviding>
@end
