//
//  UnreadCount.h
//  weibo3
//
//  Created by 吴天 on 11-5-7.
//  Copyright 2011年 nfsysu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UnreadCount : NSObject {
    
    int comments;
	int followers;
    int new_status;
	int dm;
    int mentions;
    
	
}

@property (readwrite,assign) int comments;
@property (readwrite,assign) int followers;
@property (readwrite,assign) int new_status;
@property (readwrite,assign) int dm;
@property (readwrite,assign) int mentions;


@end
