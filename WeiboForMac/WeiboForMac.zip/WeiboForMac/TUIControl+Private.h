//
//  TUIControl+Private.h
//  TwUI
//
//  Created by Josh Abernathy on 7/19/11.
//  Copyright 2011 Maybe Apps, LLC. All rights reserved.
//

#import "TUIControl.h"

@interface TUIControl (Private)

- (void)_stateWillChange;
- (void)_stateDidChange;

@end
