//
//  WTThumbPicView.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-7.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTThumbPicView.h"
#import "WTPopoverViewController.h"
#import "TUIKit.h"
#import "TUITableView+WTAddition.h"

#define POPOVER_OFFSET 10.0f

@implementation WTThumbPicView

@synthesize midPicUrl;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    return self;
}


- (void)mouseDown:(NSEvent *)theEvent{
    [[self superview] mouseDown:theEvent];
    
    //  \/ frame
    //  _______
    // |       |  ___
    // |       | |   |
    // |  point|<    |
    // |       | |___|
    // |_______|
    //
    NSPoint point = self.frame.origin;
    point.x += self.frame.size.width;
    point.y += self.frame.size.height/2;
    point.y += self.superview.frame.origin.y + [(TUITableView *)self.superview.superview contentOffSet].y;
    point.x -= POPOVER_OFFSET;

    [[WTPopoverViewController shared] displayPopoverInWindow:[NSApp mainWindow] atPoint:point];
    [[WTPopoverViewController shared] showImageWithUrlString:midPicUrl];
}

- (void)prepare{
    //if(_image)[_image release];
    [self setImage:nil];
}
@end
