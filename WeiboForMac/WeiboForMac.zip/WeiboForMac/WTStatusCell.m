//
//  WTStatusCell.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-1.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTStatusCell.h"

#define SCROLLER_WIDTH

@interface WTStatusCell (Private)
- (void)setShouldShowControlPanel:(BOOL) control;
- (void)keepPanelOn;
@end

@implementation WTStatusCell

@synthesize avatar , name , content , thumb , time;

- (id)initWithStyle:(TUITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
	if((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        _cellFlags.isMouseInside = NO;
        
        avatar = [[WTHeadImageView alloc] init];
        avatar.autoresizingMask = TUIViewAutoresizingFlexibleBottomMargin;
        avatar.layer.cornerRadius = 4.0;
        avatar.clipsToBounds = YES;
        avatar.backgroundColor = [TUIColor clearColor];
        //[avatar setUserInteractionEnabled:NO];
        [self addSubview:avatar];
        
        thumb = [[WTThumbPicView alloc] init];
        thumb.autoresizingMask = TUIViewAutoresizingFlexibleRightMargin;
        thumb.layer.cornerRadius = 3.0;
        thumb.clipsToBounds = YES;
        thumb.backgroundColor = [TUIColor clearColor];
        //[thumb setUserInteractionEnabled:NO];
        [self addSubview:thumb];
        
        name = [[WTTextRenderer alloc] init];
        content = [[WTTextRenderer alloc] init];
        time = [[TUITextRenderer alloc] init];
        self.textRenderers = [NSArray arrayWithObjects:name,content,time, nil];
        
        
        panel = [[WTControlPanel alloc] init];
        panel.backgroundColor = [TUIColor clearColor];
        [self addSubview:panel];
        panel.alpha = 0.0;
        
        self.viewDelegate = self;
	}
	return self;
}

- (void)dealloc
{
    [avatar release];
    [name release];
    [content release];
    [thumb release];
    [time release];
    [panel release];
	[super dealloc];
}

- (void)prepareForReuse{
    [avatar prepare];
    [thumb prepare];
    [super prepareForReuse];
}

- (void)prepareForDisplay{
    avatar.frame = CGRectMake(10,  self.frame.size.height-60, 50, 50);
    //name.frame = CGRectMake(70,  self.frame.size.height-60, 50, 50);
    //[[name text] drawInRect:name.bounds withAttributes:nil];
}

- (void)drawRect:(CGRect)rect
{
	CGRect b = self.bounds;
	CGContextRef ctx = TUIGraphicsGetCurrentContext();
	
	if(self.selected) {
		// gray gradient
        
        CGFloat colorA[] = { 221.0/255.0, 221.0/255.0, 221.0/255.0, 1.0 };
        CGFloat colorB[] = { 234.0/255.0, 234.0/255.0, 234.0/255.0, 1.0 };
        CGContextDrawLinearGradientBetweenPoints(ctx, 
                                                 CGPointMake(0, b.size.height)  , colorA, 
                                                 CGPointMake(0, b.size.height-5), colorB);
        
        CGFloat colorC[] = { 234.0/255.0, 234.0/255.0, 234.0/255.0, 1.0 };
        CGFloat colorD[] = { 244.0/255.0, 244.0/255.0, 244.0/255.0, 1.0 };
        CGContextDrawLinearGradientBetweenPoints(ctx, 
                                                 CGPointMake(0, b.size.height-5), colorC, 
                                                 CGPointMake(0, 0)              , colorD);
		// emboss
		CGContextSetRGBFillColor(ctx, 182.0/255.0, 182.0/255.0, 182.0/255.0, 1.0); // light at the top
		CGContextFillRect(ctx, CGRectMake(0, b.size.height-1, b.size.width, 1));
        CGContextSetRGBFillColor(ctx, 235.0/255.0, 235.0/255.0, 235.0/255.0, 1.0); // dark at the bottom
		CGContextFillRect(ctx, CGRectMake(0, 1, b.size.width, 1));
		CGContextSetRGBFillColor(ctx, 211.0/255.0, 211.0/255.0, 211.0/255.0, 1.0); // dark at the bottom
		CGContextFillRect(ctx, CGRectMake(0, 0, b.size.width, 1));
	} else {
        // gray gradient
        CGFloat colorA[] = { 251.0/255.0, 251.0/255.0, 251.0/255.0, 1.0 };
        CGFloat colorB[] = { 247.0/255.0, 247.0/255.0, 247.0/255.0, 1.0 };
        CGContextDrawLinearGradientBetweenPoints(ctx, CGPointMake(0, b.size.height), colorA, CGPointMake(0, 0), colorB);
		
		// emboss
		CGContextSetRGBFillColor(ctx, 254.0/255.0, 254.0/255.0, 254.0/255.0, 1.0); // light at the top
		CGContextFillRect(ctx, CGRectMake(0, b.size.height-1, b.size.width, 1));
		CGContextSetRGBFillColor(ctx, 235.0/255.0, 235.0/255.0, 235.0/255.0, 1.0); // dark at the bottom
		CGContextFillRect(ctx, CGRectMake(0, 0, b.size.width, 1));
	}
	
	// text
    CGFloat relativeWidth = (_cellFlags.isMouseInside ? 80.0:50.0);
    CGRect nameRect = CGRectMake(70, b.size.height-30, b.size.width-80-relativeWidth, 20);
	name.frame = nameRect; // set the frame so it knows where to draw itself
    [name draw];
    
    CGRect contentRect = CGRectMake(70, 10, b.size.width - 80, b.size.height - 38);
    content.frame = contentRect;
    //content.view.autoresizingMask = TUIViewAutoresizingFlexibleSize;
    [content draw];
    
    CGRect panelRect = CGRectMake(b.size.width - 10 - 60, b.size.height - 14 -10, 60, 14);
    panel.frame = panelRect;
    
    if (!_cellFlags.isMouseInside) {
        CGRect timeRect = CGRectMake(b.size.width - 50 - 10, b.size.height-30, 50, 20);
        time.frame = timeRect;
        [time draw];
    }
    panel.alpha = (_cellFlags.isMouseInside ? 1.0:0.0);
}

/**
 * ------------------------------------------------
 * Event Handle (Controll Panel & Time Panel)
 * ------------------------------------------------
 */

/*
- (NSArray *)sortedSubviews // back to front order
{
	return [self.subviews sortedArrayWithOptions:NSSortStable usingComparator:(NSComparator)^NSComparisonResult(TUIView *a, TUIView *b) {
		CGFloat x = a.layer.zPosition;
		CGFloat y = b.layer.zPosition;
		if(x > y)
			return NSOrderedDescending;
		else if(x < y)
			return NSOrderedAscending;
		return NSOrderedSame;
	}];
}

- (TUIView *)hitTest:(CGPoint)point withEvent:(id)event{
    if((self.userInteractionEnabled == NO) || (self.hidden == YES) || (self.alpha <= 0.0f))
		return nil;
    
	if([self pointInside:point withEvent:event]) {
		NSArray *s = [self sortedSubviews];
        if ([(NSEvent *) event type] == 5) {
            [self keepPanelOn];
        }
        NSLog(@"event:%ld",[(NSEvent *) event type]);
		for(TUIView *v in [s reverseObjectEnumerator]) {
			TUIView *hit = [v hitTest:[self convertPoint:point toView:v] withEvent:event];
			if(hit)
				return hit;
		}
		return self; // leaf
	}
	return nil;
}
*/
- (void)updateViewAnimated{
    
    [TUIView animateWithDuration:0.3 animations:^{
        [self redraw];
    }];
}

- (void)scrollWheel:(NSEvent *)theEvent{
    [super scrollWheel:theEvent];
    if (_cellFlags.isMouseInside) {
        _cellFlags.isMouseInside = NO;
        [self updateViewAnimated];
    }
}

- (void)mouseEntered:(NSEvent *)theEvent{
    if ([self eventInside:theEvent] && !_cellFlags.isMouseInside) {
        _cellFlags.isMouseInside = YES;
        [self updateViewAnimated];
    }
    [super mouseEntered:theEvent];
}

- (void)mouseExited:(NSEvent *)theEvent{
    if (![self eventInside:theEvent] && _cellFlags.isMouseInside) {
        _cellFlags.isMouseInside = NO;
        [self updateViewAnimated];
    }
    [super mouseExited:theEvent];
}

- (void)mouseUp:(NSEvent *)theEvent{
    [super mouseUp:theEvent];
}

- (void)rightMouseUp:(NSEvent *)theEvent{
    NSLog(@"rightMouse");
}
@end
