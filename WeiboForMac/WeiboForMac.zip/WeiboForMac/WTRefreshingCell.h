//
//  WTRefreshingCell.h
//  Example
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"

@interface WTRefreshingCell : TUITableViewCell {
    TUIActivityIndicatorView * activityView;
}

@end
