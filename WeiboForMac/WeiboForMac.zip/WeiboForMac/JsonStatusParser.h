//
//  JsonStatusParser.h
//  weibo4objc
//
//  Created by fanng yuan on 12/14/10.
//  Copyright 2010 fanngyuan@sina. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Status.h"
#import "WComment.h"
#import "UnreadCount.h"
#import "DirectMessage.h"
#import "ServerSideError.h"

@interface JsonStatusParser : NSObject {

}

+ (User *) dicToUser:(NSDictionary *) dic;

+ (NSArray *) parseToDictionaryArrayWithString:(NSString *) aString;
+ (ServerSideError *) parsetoServerSideError:(NSString *) errorString;
+ (NSArray *) parseToStatuses:(NSString *) statusesString;
+ (Status *) parseToStatus:(NSString *)statusString;
+ (NSArray *) parseToComments:(NSString *) commentsString;
//+ (Comment *) parseToComment:(NSString *) commentStrig;
+ (WComment *) parseToComment:(NSString *) commentStrig;
+ (NSArray *) parseToDms:(NSString *) dmsString;
+ (User *) parseToUsers:(NSString *) dmsString;
+ (DirectMessage *) parseToDm:(NSString *) dmString;
+ (UnreadCount *) parseToUnreadCount:(NSString *)statusString;

+ (NSArray *)parseMemoryTest:(NSString *)statusesString;

@end
