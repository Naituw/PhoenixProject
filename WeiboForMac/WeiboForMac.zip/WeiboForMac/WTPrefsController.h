//
//  WTPrefsController.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-7-31.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "DBPrefsWindowController.h"

@interface WTPrefsController : DBPrefsWindowController <NSWindowDelegate>{
    IBOutlet NSView *generalPreferenceView;
    IBOutlet NSView *userPreferenceView;
	IBOutlet NSView *notificationPreferenceView;
}

@end
