//
//  TUITextViewEditor.h
//  TwUI
//
//  Created by Josh Abernathy on 8/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TUITextEditor.h"

@interface TUITextViewEditor : TUITextEditor

@end
