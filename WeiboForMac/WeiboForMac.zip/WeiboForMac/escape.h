/*
 *  escape.h
 *  weibo4objc
 *
 *  Created by fanng yuan on 12/21/10.
 *  Copyright 2010 fanngyuan@sina. All rights reserved.
 *
 */

char *urlEscape(const char *string,
                                   int length);
char *urlUnescape(const char *string,
                                int length);
