//
//  WTThumbPicView.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-7.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTThumbPicView+webImage.h"
#import "SDWebImageManager.h"

@implementation WTThumbPicView (webImage)

- (void)setImageWithURL:(NSURL *)url
{
    [self setImageWithURL:url placeholderImage:nil];
}

- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder
{
    SDWebImageManager *manager = [SDWebImageManager sharedManager];
    
    // Remove in progress downloader from queue
    [manager cancelForDelegate:self];
    
    if (placeholder) {
        self.image = [TUIImage imageWithNSImage:placeholder];
    }
    
    
    if (url)
    {
        [manager downloadWithURL:url delegate:self];
    }
}

- (void)cancelCurrentImageLoad
{
    [[SDWebImageManager sharedManager] cancelForDelegate:self];
}

- (void)webImageManager:(SDWebImageManager *)imageManager didFinishWithImage:(UIImage *)image
{
    if (image) {
        self.image = [TUIImage imageWithNSImage:image];
        CGSize size = [self.image size];
        CGFloat height = 90.0;
        CGFloat width = size.width * height / size.height;
        if (width > 160) {
            width = 160.0;
            height = size.height * width / size.width;
        }
        self.frame = CGRectMake(70, 13, width, height);
    }
    
}


@end
