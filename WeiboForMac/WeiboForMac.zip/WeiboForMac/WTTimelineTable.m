//
//  WTTimelineTable.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-28.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTTimelineTable.h"
#import "WTStatusCell.h"

@implementation WTTimelineTable
@synthesize pullView;

- (id)initWithFrame:(CGRect)frame style:(TUITableViewStyle)style{
    self = [super initWithFrame:frame style:style];
    if (self) {
        self.autoresizingMask = TUIViewAutoresizingFlexibleSize;
        self.backgroundColor = [TUIColor colorWithWhite:245.0/255.0 alpha:1.0];
        pullView = [[WTPullDownView alloc] initWithScrollView:self];
        self.pullDownView = pullView;
    }
    return self;
}

- (void)mouseEntered:(NSEvent *)event onSubview:(TUIView *)subview{
    if ([subview isKindOfClass:[WTStatusCell class]]) {
        //NSLog(@"entered");
    }
}

- (void)mouseExited:(NSEvent *)event fromSubview:(TUIView *)subview{
    if ([subview isKindOfClass:[WTStatusCell class]]) {
        NSLog(@"exited");
    }
}

@end
