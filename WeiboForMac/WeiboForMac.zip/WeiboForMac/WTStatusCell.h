//
//  WTStatusCell.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-1.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"
#import "WTHeadImageView.h"
#import "WTThumbPicView.h"
#import "WTTextRenderer.h"
#import "WTControlPanel.h"

@interface WTStatusCell : TUITableViewCell <TUIViewDelegate> {
    WTHeadImageView * avatar;
    TUITextRenderer * name;
    WTTextRenderer * content;
    WTThumbPicView * thumb;
    
    TUITextRenderer * time;
    WTControlPanel * panel;
    
    struct {
		unsigned int isMouseInside:1;
        unsigned int isHoverPanel:1;
	} _cellFlags;
}

@property (nonatomic , retain) WTHeadImageView  * avatar;
@property (nonatomic , retain) TUITextRenderer  * name;
@property (nonatomic , retain) WTTextRenderer  * content;
@property (nonatomic , retain) WTThumbPicView * thumb;
@property (nonatomic , retain) TUITextRenderer * time;

@end
