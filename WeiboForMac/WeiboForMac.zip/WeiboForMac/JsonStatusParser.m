//
//  JsonStatusParser.m
//  weibo4objc
//
//  Created by fanng yuan on 12/14/10.
//  Copyright 2010 fanngyuan@sina. All rights reserved.
//

#import "JsonStatusParser.h"
#import "SBJsonParser.h"
#import "WTStatus.h"

@implementation JsonStatusParser

+ (NSArray *) parseToDictionaryArrayWithString:(NSString *) aString{
    
    SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSArray * array = [jsonParser objectWithString:aString error:&error];
    
    return array;
    
}

+ (Status *) dicToStatus:(NSDictionary *) dic {
	Status * status = [[Status alloc] init];
	[status setText:[dic objectForKey:@"text"]];

    NSDate *date = [NSDate dateWithNaturalLanguageString:[dic objectForKey:@"created_at"]];
	int statusDateAsSeconds = (int)[date timeIntervalSinceReferenceDate];
    
    [status setCreated_at:statusDateAsSeconds];
	[status setAid:[[dic objectForKey:@"id"] longLongValue]];
	[status setSource:[dic objectForKey:@"source"]];
	[status setFavorited:[[dic objectForKey:@"favorited"] boolValue]];
	[status setTruncated:[[dic objectForKey:@"truncated"] boolValue]];
	[status setIn_reply_to_status_id:[[dic objectForKey:@"in_reply_to_status_id"] longLongValue]];
	[status setIn_reply_to_user_id:[[dic objectForKey:@"in_reply_to_user_id"] intValue]];
	[status setIn_reply_to_screen_name:[dic objectForKey:@"in_reply_to_screen_name"]];
	[status setThumbnail_pic:[dic objectForKey:@"thumbnail_pic"]];
	[status setBmiddle_pic:[dic objectForKey:@"bmiddle_pic"]];
	[status setOriginal_pic:[dic objectForKey:@"original_pic"]];
	[status setLatitude:[[dic objectForKey:@"latitude"] doubleValue]];
	[status setLongitude:[[dic objectForKey:@"longitude"] doubleValue]];
    
	if ([dic objectForKey:@"retweeted_status"]) {
		[status setRetweeted_status:[JsonStatusParser dicToStatus:[dic objectForKey:@"retweeted_status"]]];
	}

	[status setUser:[JsonStatusParser dicToUser:[dic objectForKey:@"user"]]];
    
	return status;
} 

+ (NSArray *) parseToStatuses:(NSString *) statusesString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSArray * array = [jsonParser objectWithString:statusesString error:&error];
	NSMutableArray * result = [[NSMutableArray alloc] init];
	for(NSDictionary * dic in array){
        NSAutoreleasePool *p = [[NSAutoreleasePool alloc] init];
        Status * status = [self dicToStatus:dic];
        WTStatus * wtStatus = [[WTStatus alloc] initWithStatus:status];
        [status release];
		[result addObject:wtStatus];
        [wtStatus release];
        [p drain];
	}
	[jsonParser release];
	return result;
}

+ (NSArray *)parseMemoryTest:(NSString *)statusesString{
    SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSArray * array = [jsonParser objectWithString:statusesString error:&error];
	NSMutableArray * result = [[NSMutableArray alloc] init];
	for(NSDictionary * dic in array){
        Status * status = [self dicToStatus:dic];
		[result addObject:status];
        [status release];
	}
	[jsonParser release];
	return result;
}



+ (Status *) parseToStatus:(NSString *)statusString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSDictionary * dic = [jsonParser objectWithString:statusString error:&error];
	Status * status = [self dicToStatus:dic];
	[jsonParser release];
	return status;	
}

+ (UnreadCount *) dicToURCount:(NSDictionary *) dic{
	UnreadCount * count = [[UnreadCount alloc] init];
    [count setComments:[[dic objectForKey:@"comments"] intValue]];
    [count setFollowers:[[dic objectForKey:@"followers"] intValue]];
    [count setNew_status:[[dic objectForKey:@"new_status"] intValue]];
    [count setDm:[[dic objectForKey:@"dm"] intValue]];
    [count setMentions:[[dic objectForKey:@"mentions"] intValue]];
    return count;
}

+ (UnreadCount *) parseToUnreadCount:(NSString *)statusString{
    
    SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSDictionary * dic = [jsonParser objectWithString:statusString error:&error];
	UnreadCount * count = [self dicToURCount:dic];
	[jsonParser release];
	return count;	
    
}

+ (User *) parseToUsers:(NSString *)statusString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSDictionary * dic = [jsonParser objectWithString:statusString error:&error];
	User * user = [self dicToUser:dic]; 
	[jsonParser release];
	return user;	
}

+ (User *) dicToUser:(NSDictionary *) dic{
	User * user = [[User alloc] init];
	[user setUid:[[dic objectForKey:@"id"] intValue]];
	[user setScreen_name:[dic objectForKey:@"screen_name"]];
	[user setName:[dic objectForKey:@"name"]];
	[user setProvince:[dic objectForKey:@"provice"]];
	[user setCity:[dic objectForKey:@"city"]];
	[user setLocation:[dic objectForKey:@"location"]];
	[user setDescription:[dic objectForKey:@"description"]];
	[user setUrl:[dic objectForKey:@"url"]];
	[user setProfile_image_url:[dic objectForKey:@"profile_image_url"]];
	[user setDomain:[dic objectForKey:@"domain"]];
	[user setGender:[dic objectForKey:@"gender"]];
	[user setFollowers_count:[[dic objectForKey:@"followers_count"] intValue]];
	[user setFriends_count:[[dic objectForKey:@"friends_count"] intValue]];
	[user setStatuses_count:[[dic objectForKey:@"statuses_count"] intValue]];
	[user setFavourites_count:[[dic objectForKey:@"favourites_count"] intValue]];
    
    NSString *dateString = [dic objectForKey:@"created_at"];
    if (dateString) {
        NSDate *date = [NSDate dateWithNaturalLanguageString:dateString];
        int statusDateAsSeconds = (int)[date timeIntervalSinceReferenceDate];
        [user setCreated_at:statusDateAsSeconds];
    }
	[user setFollowing:[[dic objectForKey:@"following"] boolValue]];
	[user setVerified:[[dic objectForKey:@"verified"] boolValue]];
	[user setAllow_all_act_msg:[[dic objectForKey:@"allow_all_act_msg"] boolValue]];
	[user setGeo_enabled:[[dic objectForKey:@"geo_enabled"] boolValue]];
	if([dic objectForKey:@"status"])
		[user setStatus:[JsonStatusParser dicToStatus:[dic objectForKey:@"status"]]];
	return user;
}

+ (WComment *) dicToComment:(NSDictionary *) dic{
	WComment * comment = [[WComment alloc] init];
    
    NSAutoreleasePool *p = [[NSAutoreleasePool alloc] init];
    NSDate *date = [NSDate dateWithNaturalLanguageString:[dic objectForKey:@"created_at"]];
	int statusDateAsSeconds = (int)[date timeIntervalSinceReferenceDate];
    [p drain];
    
	[comment setCreated_at:statusDateAsSeconds];
	[comment setAid:[[dic objectForKey:@"id"]longLongValue]];
	[comment setText:[dic objectForKey:@"text"]];
	[comment setUser:[JsonStatusParser dicToUser:[dic objectForKey:@"user"]]];
    [comment setStatus:[JsonStatusParser dicToStatus:[dic objectForKey:@"status"]]];
    if ([dic objectForKey:@"reply_comment"]!= nil) {
        [comment setReply_comment:[JsonStatusParser dicToComment:[dic objectForKey:@"reply_comment"]]];
    }
	return comment;
}


+ (WComment *) parseToComment:(NSString *) commentStrig{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSDictionary * dic = [jsonParser objectWithString:commentStrig error:&error];
	WComment * comment = [self dicToComment:dic];
	[jsonParser release];
	//[dic release];
	return comment;	
}

+ (NSArray *) parseToComments:(NSString *) commentsString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSArray * array = [jsonParser objectWithString:commentsString error:&error];
	NSMutableArray * result = [[NSMutableArray alloc] init];
	for(NSDictionary * dic in array){
		[result addObject:[self dicToComment:dic]];
	}
	[jsonParser release];
	[array release];
	return result;
}

+ (DirectMessage *) dicToDm:(NSDictionary *) dic{
	DirectMessage * dm = [[DirectMessage alloc]init];
    
    NSAutoreleasePool *p = [[NSAutoreleasePool alloc] init];
    NSDate *date = [NSDate dateWithNaturalLanguageString:[dic objectForKey:@"created_at"]];
	int statusDateAsSeconds = (int)[date timeIntervalSinceReferenceDate];
    [p drain];
    
	[dm setCreated_at:[NSDate dateWithNaturalLanguageString:statusDateAsSeconds]];
	[dm setAid:(weiboId)[dic objectForKey:@"id"]];
	[dm setText:[dic objectForKey:@"text"]];
	[dm setSender_id:(int)[dic objectForKey:@"sender_id"]];
	[dm setRecipient_id:(int)[dic objectForKey:@"recipient_id"]];
	[dm setSender_screen_name:[dic objectForKey:@"sender_screen_name"]];
	[dm setRecipient_screen_name:[dic objectForKey:@"recipient_screen_name"]];
	[dm setSender:[JsonStatusParser dicToUser:[dic objectForKey:@"sender"]]];
	[dm setRecipient:[JsonStatusParser dicToUser:[dic objectForKey:@"recipient"]]];
	return dm;		
}

+ (NSArray *) parseToDms:(NSString *) dmsString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSArray * array = [jsonParser objectWithString:dmsString error:&error];
	NSMutableArray * result = [[NSMutableArray alloc] init];
	for(NSDictionary * dic in array){
		[result addObject:[self dicToDm:dic]];
	}
	[jsonParser release];
	[array release];
	return result;
}

+ (DirectMessage *) parseToDm:(NSString *) dmString{
	SBJsonParser *jsonParser = [[SBJsonParser alloc] init];
	NSError * error;
	NSDictionary * dic = [jsonParser objectWithString:dmString error:&error];
	[jsonParser release];
	DirectMessage * dm = [self dicToDm:dic];
	[dic release];
	return dm;		
}



+ (ServerSideError *) parsetoServerSideError:(NSString *) errorString{
	SBJsonParser * jsonParser = [[SBJsonParser alloc] init];
	NSDictionary * dic =[jsonParser objectWithString:errorString error:nil];
	ServerSideError * error = [[ServerSideError alloc] init];
	[error setRequest:[dic objectForKey:@"request"]];
	[error setError_code:[[dic objectForKey:@"error_code"] intValue]];
	[error setError:[dic objectForKey:@"error"]];
	[jsonParser release];
	return error;
}

@end
