//
//  WTSectionAvatarView.h
//  WTTabbarController
//
//  Created by Wu Tian on 11-8-21.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"

@interface WTSectionAvatarView : TUIView {
    TUIImage * avatar;
}

@property (assign) TUIImage *avatar;

- (id)initWithAvatar:(TUIImage *)aAvatar;

@end
