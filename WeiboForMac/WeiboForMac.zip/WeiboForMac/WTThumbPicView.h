//
//  WTThumbPicView.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-7.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIImageView.h"

@interface WTThumbPicView : TUIImageView {
    NSString * midPicUrl;
}

@property (assign) NSString * midPicUrl;
- (void)prepare;
@end
