//
//  WTTabViewController.m
//  WTTabbarController
//
//  Created by Wu Tian on 11-8-20.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTTabViewController.h"
#import "WTButtonCell.h"
#import "WTMainWindow.h"

@implementation WTTabViewController
@synthesize avatarImage;

- (id)initWithFrame:(CGRect)frame
{
	if((self = [super initWithFrame:frame])) {
        tabView = [[WTDragableTableView alloc] initWithFrame:frame style:TUITableViewStylePlain];
        tabView.autoresizingMask = (TUIViewAutoresizingFlexibleHeight);
        tabView.delegate = self;
        tabView.dataSource = self;
        tabView.drawRect = ^(TUIView *v, CGRect rect) {
            CGRect b = self.bounds;
            CGContextRef ctx = TUIGraphicsGetCurrentContext();
            CGContextSetRGBFillColor(ctx, .13, .13, .13, 13);
            CGContextFillRect(ctx, b);
        };
        [self addSubview:tabView];
        selectedTab = -1;
    }
    return self;
}

- (void)dealloc
{
	[tabView release];
	[super dealloc];
}

/**
 *  tableViewDelegate
 *  tableViewDatasource
 */

- (NSInteger)numberOfSectionsInTableView:(TUITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(TUITableView *)table numberOfRowsInSection:(NSInteger)section
{
	return 5;
}

- (CGFloat)tableView:(TUITableView *)tableView heightForRowAtIndexPath:(TUIFastIndexPath *)indexPath
{
	return 38.0;
}

- (TUITableViewCell *)tableView:(TUITableView *)tableView cellForRowAtIndexPath:(TUIFastIndexPath *)indexPath{
    WTButtonCell * cell = reusableTableCellOfClass(tabView, WTButtonCell);
    
    // init select first tab
    if (selectedTab == -1 && indexPath.row == 0) {
        cell.lighted = YES;
        selectedTab = 0;
    }
    return cell;
}

- (TUIView *)tableView:(TUITableView *)tableView headerViewForSection:(NSInteger)section{
    if (!sectionView) {
        sectionView = [[WTSectionAvatarView alloc] initWithAvatar:avatarImage];
    }
    return sectionView;
}

- (void)tableView:(TUITableView *)tableView didClickRowAtIndexPath:(TUIFastIndexPath *)indexPath withEvent:(NSEvent *)event
{
    WTButtonCell * theCell = [[tableView visibleCells] objectAtIndex:indexPath.row];
    WTButtonCell * preCell = [[tableView visibleCells] objectAtIndex:selectedTab];
	if([event clickCount] == 1) {
        // make selected tab highlight.
        preCell.lighted = NO;
        theCell.lighted = YES;
        [TUIView animateWithDuration:0.2 animations:^{
            [preCell redraw];
        }];
        selectedTab = indexPath.row;
        
        //
	}
    
	if(event.type == NSRightMouseUp){
		// show context menu
	}
}

- (void) setTabAtIndex:(NSUInteger)index shouldShowGlow:(BOOL) show{
    WTButtonCell * theCell = [[tabView visibleCells] objectAtIndex:index];
    [theCell setShouldShowGlow:show];
}

- (void) selectTabAtIndex:(NSUInteger)index{
    NSUInteger preRow = [tabView selectedRow];
    [tabView selectRowAtIndexPath:[TUIFastIndexPath 
                                   indexPathForRow:index inSection:0] 
                         animated:YES 
                   scrollPosition:TUITableViewScrollPositionNone];
    WTButtonCell * theCell = [[tabView visibleCells] objectAtIndex:preRow];
    WTButtonCell * preCell = [[tabView visibleCells] objectAtIndex:index];
    preCell.lighted = NO;
    theCell.lighted = YES;
    selectedTab = index;
}

@end
