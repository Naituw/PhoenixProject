//
//  WTTextRenderer.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-7.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTTextRenderer.h"

@implementation WTTextRenderer

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


- (void)mouseUp:(NSEvent *)event{
    [super mouseUp:event];
    NSLog(@"hitRange:%u",self.hitRange.rangeFlavor);
    if(self.hitRange.rangeFlavor == ABActiveTextRangeFlavorURL) {
        if([self.hitRange respondsToSelector:@selector(openUrl:)]) {
            [self.hitRange performSelector:@selector(openUrl:) withObject:[(ABFlavoredRange *)self.hitRange displayString]];
        }
    }
    else if(self.hitRange.rangeFlavor == ABActiveTextRangeFlavorTwitterUsername){
        [[NSApp mainWindow] setTitle:[(ABFlavoredRange *)self.hitRange displayString]];
    }
    self.hitRange = nil;
    [self.view redraw];
}



@end
