//
//  UnreadCount.m
//  weibo3
//
//  Created by 吴天 on 11-5-7.
//  Copyright 2011年 nfsysu. All rights reserved.
//

#import "UnreadCount.h"


@implementation UnreadCount

@synthesize comments, followers, new_status, dm, mentions;

- (id)init
{
    self = [super init];
    if (self) {
        comments = 0;
        followers = 0;
        new_status = 0;
        dm = 0;
        mentions = 0;
    }
    
    return self;
}

- (NSString *) description{
	NSMutableString * desc = [[NSMutableString alloc]init];
	[desc appendFormat:@"\ncomments: %d", [self comments]];
	[desc appendFormat:@"\nfollowers: %d", [self followers]];
	[desc appendFormat:@"\nnew_status: %d", [self new_status]];
	[desc appendFormat:@"\ndm: %d", [self dm]];
    [desc appendFormat:@"\nmentions: %d", [self mentions]];
	return desc;
}


@end
