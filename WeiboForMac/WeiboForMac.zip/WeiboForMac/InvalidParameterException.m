//
//  InvalidParameterException.m
//  weibo4objc
//
//  Created by fanng yuan on 12/16/10.
//  Copyright 2010 fanngyuan@sina. All rights reserved.
//

#import "InvalidParameterException.h"


@implementation InvalidParameterException

+ (InvalidParameterException *)exceptionWithName:(NSString *)name 
                                          reason:(NSString *)reason 
                                        userInfo:(NSDictionary *)userInfo{
    return (InvalidParameterException *)[super exceptionWithName:name reason:reason userInfo:userInfo];
}

@end
