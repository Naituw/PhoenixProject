//
//  WTHeadImageView.h
//  WeiboForMac
//
//  Created by Wu Tian on 11-8-4.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIImageView.h"

@interface WTHeadImageView : TUIImageView

- (void)prepare;
@end
