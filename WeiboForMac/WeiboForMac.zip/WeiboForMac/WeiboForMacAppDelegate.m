//
//  WeiboForMacAppDelegate.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-7-31.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WeiboForMacAppDelegate.h"
#import "WTPrefsController.h"
#import "WTInformation.h"
#import "Weibo.h"
#import "INAppStoreWindow.h"

@implementation WeiboForMacAppDelegate

- (void)initUserDefaults
{
    NSUserDefaults * ud = [NSUserDefaults standardUserDefaults];
    if (![ud objectForKey:@"autoLogin"]) {
        [ud setBool:YES forKey:@"autoLogin"];
    }
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    
    [self initUserDefaults];
    if ([[WTInformation center] shoudAutoLogin]) {
        NSString * autoLoginName;
        if ((autoLoginName = [[WTInformation center] autoLoginUserName])) {
            OAToken * token = [[WTInformation center] getAccessTokenForUserName:autoLoginName];
            [[Weibo engine] set_accessToken:token];
            //[[WTMainWindow shared] showWindowWithUser:[[Weibo engine] verifyUser]];
            
            /*
            NSArray * tempArray;
            
            
            tempArray = [[Weibo engine] memoryTestPage:1];
            NSMutableArray * array = [[NSMutableArray alloc] initWithArray:tempArray];
            [tempArray release];
            
            tempArray = [[Weibo engine] memoryTestPage:2];
            [array addObjectsFromArray:tempArray];
            [tempArray release];
            
            tempArray = [[Weibo engine] memoryTestPage:3];
            [array addObjectsFromArray:tempArray];
            [tempArray release];
            
            [array release];
            */
            
            NSMutableArray * array = [[NSMutableArray alloc] initWithArray:[[Weibo engine] getFriendsTimeline:0 maxId:0 count:200 page:1]];

            NSLog(@"done");
            NSLog(@"array count:%ld",[array count]);
        }
        else{
            [self setShouldLogin];
        }
    }
    else{
        [[WTInformation center] clearAutoLoginInfomation];
        [self setShouldLogin];
    }
     
    
    
    
}

- (void)applicationWillTerminate:(NSNotification *)aNotification{
    [loginWindowController release];
}

-(void) setShouldLogin{
    if (!loginWindowController) {
        loginWindowController = [[WTLoginWindow alloc] 
                                 initWithWindowNibName:@"WTLoginWindow"];
    }
    [loginWindowController.window display];
    [loginWindowController.window makeKeyAndOrderFront:self];
}

- (IBAction) showPreferenceWindow:(id) sender{
    [[WTPrefsController sharedPrefsWindowController] showWindow:nil];
}

@end
