//
//  WTPrefsController.m
//  WeiboForMac
//
//  Created by Wu Tian on 11-7-31.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "WTPrefsController.h"
#import "WTMainWindow.h"
#import "TUITableView+WTAddition.h"

@implementation WTPrefsController

- (void)setupToolbar
{
	[self addView:generalPreferenceView label:@"常规　　" image:[NSImage imageNamed:NSImageNamePreferencesGeneral]];
    [self addView:userPreferenceView label:@"用户　　" image:[NSImage imageNamed:NSImageNameUserAccounts]];
    [self addView:notificationPreferenceView label:@"通知　　" image:[NSImage imageNamed:@"NotificationPrefs.png"]];
	
    // Optional configuration settings.
	[self setCrossFade:YES];
	[self setShiftSlowsAnimation:YES];
    
    [self window].delegate = self;
}

- (void)windowWillClose:(NSNotification *)notification{
    // refresh current timeline view.
    [[[[WTMainWindow shared] timeLineView] friendTimeline] pushNewRowsWithCount:0];
}

@end
