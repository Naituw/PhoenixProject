//
//  WTDateFormatter.m
//  weibo3
//
//  Created by 吴天 on 11-7-15.
//  Copyright 2011年 nfsysu. All rights reserved.
//

#import "WTDateFormatter.h"

static WTDateFormatter * shared = nil;

@implementation WTDateFormatter

+ (WTDateFormatter * ) shared {
    if (!shared) {
        shared = [[WTDateFormatter alloc] init];
    }
    return shared;
}

- (void)dealloc{
    [super dealloc];
}



- (NSString *) stringForTime:(int)time {
	// Get time difference
	int currentDateAsSeconds = (int) [NSDate timeIntervalSinceReferenceDate];
	int seconds = currentDateAsSeconds - time;
    
    /*
	// Check whether it's years away
	int yearInSecs = 12 * 4 * 7 * 24 * 60 * 60;
	int years = seconds / yearInSecs;
	if (years > 0) {
		if (years > 1) {
			return @"几年前";
		} else {
			return @"一年前";
		}
	}
	
	// check whether it's months away
	int monthInSecs = 4 * 7 * 24 * 60 * 60;
	int months = seconds / monthInSecs;
	int secsAfterMonths = seconds % monthInSecs;
	if (secsAfterMonths > 2 * 7 * 24 * 60 * 60) {
		months++;
	}
	if (months > 0) {
		if (months > 1) {
			return [NSString stringWithFormat:@"%i 个月前", months];
		} else {
			return @"1个月前";
		}
	}
	
	// check whether it's weeks away
	int weekInSecs = 7 * 24 * 60 * 60;
	int weeks = seconds / weekInSecs;
	int secsAfterWeeks = seconds % weekInSecs;
	if (secsAfterWeeks > 4 * 24 * 60 * 60) {
		weeks++;
	}
	if (weeks > 0) {
		if (weeks > 1) {
			return [NSString stringWithFormat:@"%i周前", weeks];
		} else {
			return @"1周前";
		}
	}
     */
	
	// check whether it's days away
	int dayInSecs = 24 * 60 * 60;
	int days = seconds / dayInSecs;
	if (days > 0) {
		if (days > 1) {
			return [NSString stringWithFormat:@"%i天", days];
		} else {
			return @"1天前";
		}
	}
	
	// check whether it's hours away
	int hourInSecs = 60 * 60;
	int hours = seconds / hourInSecs;
	if (hours > 0) {
		if (hours > 1) {
			return [NSString stringWithFormat:@"%i小时前", hours];
		} else {
			return @"1小时前";
		}
	}
	
	// check whether it's minutes away
	int minuteInSecs = 60;
	int minutes = seconds / minuteInSecs;
	if (minutes > 0) {
		if (minutes > 1) {
			return [NSString stringWithFormat:@"%i分钟前", minutes];
		} else {
			return @"1分钟前";
		}
	}
	
	// if not any of the above, it's seconds away
	if (seconds > 1) {
		return [NSString stringWithFormat:@"%i秒前", seconds];
	} else if (seconds == 1) {
		return @"1秒前";
	} else {
		return @"刚刚";
	}
}


@end
