//
//  WTTabViewController.h
//  WTTabbarController
//
//  Created by Wu Tian on 11-8-20.
//  Copyright 2011年 Wutian. All rights reserved.
//

#import "TUIKit.h"
#import "WTDragableTableView.h"
#import "WTSectionAvatarView.h"

@interface WTTabViewController : TUIView <TUITableViewDelegate, TUITableViewDataSource>{
    WTDragableTableView * tabView;
    NSUInteger selectedTab;
    
    TUIImage * avatarImage;
    WTSectionAvatarView * sectionView;
}

@property (assign) TUIImage * avatarImage;

- (void) setTabAtIndex:(NSUInteger)index shouldShowGlow:(BOOL) show;
- (void) selectTabAtIndex:(NSUInteger)index;

@end
